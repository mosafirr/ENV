from Hermione.modules.helper_funcs.chat_status import user_admin
from Hermione.modules.disable import DisableAbleCommandHandler
from Hermione import dispatcher

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram import ParseMode, Update
from telegram.ext.dispatcher import run_async
from telegram.ext import CallbackContext, Filters, CommandHandler

MARKDOWN_HELP = f"""
Markdown is a very powerful formatting tool supported by telegram. {dispatcher.bot.first_name} has some enhancements, to make sure that \
saved messages are correctly parsed, and to allow you to create buttons.

• <code>_italic_</code>: wrapping text with '_' will produce italic text
• <code>*bold*</code>: wrapping text with '*' will produce bold text
• <code>`code`</code>: wrapping text with '`' will produce monospaced text, also known as 'code'
• <code>[sometext](someURL)</code>: this will create a link - the message will just show <code>sometext</code>, \
and tapping on it will open the page at <code>someURL</code>.
<b>Example:</b><code>[test](example.com)</code>

• <code>[buttontext](buttonurl:someURL)</code>: this is a special enhancement to allow users to have telegram \
buttons in their markdown. <code>buttontext</code> will be what is displayed on the button, and <code>someurl</code> \
will be the url which is opened.
<b>Example:</b> <code>[This is a button](buttonurl:example.com)</code>

If you want multiple buttons on the same line, use :same, as such:
<code>[one](buttonurl://github.com/prabhasha-p)
[two](buttonurl://google.com:same)</code>
This will create two buttons on a single line, instead of one button per line.

Keep in mind that your message <b>MUST</b> contain some text other than just a button!
"""


@run_async
@user_admin
def echo(update: Update, context: CallbackContext):
    args = update.effective_message.text.split(None, 1)
    message = update.effective_message

    if message.reply_to_message:
        message.reply_to_message.reply_text(
            args[1], parse_mode="MARKDOWN", disable_web_page_preview=True
        )
    else:
        message.reply_text(
            args[1], quote=False, parse_mode="MARKDOWN", disable_web_page_preview=True
        )
    message.delete()


def markdown_help_sender(update: Update):
    update.effective_message.reply_text(MARKDOWN_HELP, parse_mode=ParseMode.HTML)
    update.effective_message.reply_text(
        "Try forwarding the following message to me, and you'll see, and Use #test!"
    )
    update.effective_message.reply_text(
        "/save test This is a markdown test. _italics_, *bold*, code, "
        "[URL](example.com) [button](buttonurl:github.com/Prabhasha-p) "
        "[button2](buttonurl://google.com:same)"
    )


@run_async
def markdown_help(update: Update, context: CallbackContext):
    if update.effective_chat.type != "private":
        update.effective_message.reply_text(
            "Contact me in pm",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "Markdown help",
                            url=f"t.me/{context.bot.username}?start=markdownhelp",
                        )
                    ]
                ]
            ),
        )
        return
    markdown_help_sender(update)


HELPSTRINGS = """
*Available commands:*
*Markdown:*
 ❍ /markdownhelp*:* quick summary of how markdown works in telegram - can only be called in private chats
*Paste:*
 ❍ /paste*:* Saves replied content to `nekobin.com` and replies with a url
*React:*
 ❍ /react*:* Reacts with a random reaction 
*Urban Dictonary:*
 ❍ /ud <word>*:* Type the word or expression you want to search use
*Wikipedia:*
 ❍ /wiki <query>*:* wikipedia your query
*Wallpapers:*
 ❍ /wall <query>*:* get a wallpaper from wall.alphacoders.com
*live cricket score*
 ❍ /cs*:* Latest live scores from cricinfo
*Currency converter:* 
 ❍ /cash*:* currency converter
Example:
 `/cash 1 USD INR`  
      _OR_
 `/cash 1 usd inr`
Output: `1.0 USD = 75.505 INR`

*MATHS*
Solves complex math problems using https://newton.now.sh
❍ /math*:* Math `/math 2^2+2(2)`
❍ /factor*:* Factor `/factor x^2 + 2x`
❍ /derive*:* Derive `/derive x^2+2x`
❍ /integrate*:* Integrate `/integrate x^2+2x`
❍ /zeroes*:* Find 0's `/zeroes x^2+2x`
❍ /tangent*:* Find Tangent `/tangent 2lx^3`
❍ /area*:* Area Under Curve `/area 2:4lx^3`
❍ /cos*:* Cosine `/cos pi`
❍ /sin*:* Sine `/sin 0`
❍ /tan*:* Tangent `/tan 0`
❍ /arccos*:* Inverse Cosine `/arccos 1`
❍ /arcsin*:* Inverse Sine `/arcsin 0`
❍ /arctan*:* Inverse Tangent `/arctan 0`
❍ /abs*:* Absolute Value `/abs -1`
❍ /log*:* Logarithm `/log 2l8`

_Keep in mind_: To find the tangent line of a function at a certain x value, send the request as c|f(x) where c is the given x value and f(x) is the function expression, the separator is a vertical bar '|'. See the table above for an example request.
To find the area under a function, send the request as c:d|f(x) where c is the starting x value, d is the ending x value, and f(x) is the function under which you want the curve between the two x values.
To compute fractions, enter expressions as numerator(over)denominator. For example, to process 2/4 you must send in your expression as 2(over)4. The result expression will be in standard math notation (1/2, 3/4).

💡`Read From Top`
"""
__help__ = HELPSTRINGS

ECHO_HANDLER = DisableAbleCommandHandler("echo", echo, filters=Filters.group)
MD_HELP_HANDLER = CommandHandler("markdownhelp", markdown_help)

dispatcher.add_handler(ECHO_HANDLER)
dispatcher.add_handler(MD_HELP_HANDLER)

__mod_name__ = "📚Extras"
__command_list__ = ["id", "echo"]
__handlers__ = [
    ECHO_HANDLER,
    MD_HELP_HANDLER,
]
